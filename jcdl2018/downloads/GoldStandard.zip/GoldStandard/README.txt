Gold Standard README file

In the context of this study, the gold standard is composed by the debutant topics that emerged from the 2000 to 2011 and a list of related topics that can be considered as their “ancestors”. We con-sider also their related topics since all the approaches return a clus-ter of ancestors linked to the future emergence of a yet unlabelled topic.


FILE "debutantCS.json"
Contains a list of all debutant topics per year. Each instance has 
"id": 16698, (id in Rexplore dataset)
"Name": "semantic web", (label of the topic)
"CitationCount": 60941, 
"PublicationCount": 13525, 
"Debut": 1996, (year of first appearance of the keyword)
"rank": 4, (Klink-2 parameter, not used)
"softDebut": 2000, (year in which this label reached 5 publications)
"diffDebut": 4 (difference between the years)

FOLDER "topics"
Contains all the ancestors for the debutant topics in each year.
"semantic web": [ (label of the debutant topic)
    {
      "name2": "semantics", (label of the ancestor)
      "co": 254, (number of co-occurrences in the five first years)
      "softDebut": 1956, (debut of the ancestor)
      "class": 49.0918 (index of collaboration)
    },...]